
const trains = [
    {
        model: "2333",
        name: "F3 A-A Diesel",
        type: "Locomotive",
        era: "Postwar",
        scale: "O",
        years: "1948–1949",
        features: "Dual motors, magne-traction",
        diagram: "https://www.lionelsupport.com/media/diagrams/2333.pdf",
        notes: "Early postwar classic"
    },
    {
        model: "736",
        name: "Berkshire 2-8-4",
        type: "Steam Locomotive",
        era: "Postwar",
        scale: "O",
        years: "1953–1968",
        features: "Smoke, whistle, magnetraction",
        diagram: "https://www.lionelsupport.com/media/diagrams/736.pdf",
        notes: "Used in many starter sets"
    }
];

const tableBody = document.getElementById("trainData");
trains.forEach(train => {
    const row = document.createElement("tr");
    row.innerHTML = `
        <td>${train.model}</td>
        <td>${train.name}</td>
        <td>${train.type}</td>
        <td>${train.era}</td>
        <td>${train.scale}</td>
        <td>${train.years}</td>
        <td>${train.features}</td>
        <td><a href="${train.diagram}" target="_blank">View</a></td>
        <td>${train.notes}</td>
    `;
    tableBody.appendChild(row);
});
